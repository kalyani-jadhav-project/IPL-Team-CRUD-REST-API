package com.IPL.ipl_team;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IplTeamApplicationTests {

	@Test
	void contextLoads() {
	}

}
